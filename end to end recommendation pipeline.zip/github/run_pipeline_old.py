#!/usr/bin/env python3
"""
End-to-End Pipeline Runner - CORRECTED VERSION
"""

import subprocess
import sys
from pathlib import Path

# Get the project root directory (where this script is located)
PROJECT_ROOT = Path(__file__).parent.absolute()

def run_step(script_relative_path, description):
    """Run a single pipeline step"""
    print(f"\n{'='*60}")
    print(f"▶ {description}")
    print(f"{'='*60}")
    
    # Construct full path to script
    script_path = PROJECT_ROOT / script_relative_path
    
    # Check if script exists
    if not script_path.exists():
        print(f"❌ ERROR: Script not found at: {script_path}")
        return False
    
    # Run the script
    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=PROJECT_ROOT,  # Run from project root, not script directory
        capture_output=False
    )
    
    return result.returncode == 0

def main():
    print("\n" + "="*60)
    print("RECOMART PIPELINE - END TO END EXECUTION")
    print("="*60)
    
    steps = [
        ("data_generator.py", "Step 1: Generate Sample Data"),
        ("02_Data_Collection_Ingestion/scripts/ingest_data.py", "Step 2: Data Ingestion"),
        ("05_Data_Preparation/scripts/prepare_data.py", "Step 3: Data Preparation"),
        ("06_Feature_Engineering_Transformation/scripts/feature_engineering.py", "Step 4: Feature Engineering"),
        ("09_Model_Training_Evaluation/scripts/train_model.py", "Step 5: Model Training"),
    ]
    
    results = []
    for script_path, description in steps:
        success = run_step(script_path, description)
        results.append((description, success))
        
        if not success:
            print(f"\n❌ Pipeline failed at: {description}")
            break
    
    print("\n" + "="*60)
    print("PIPELINE EXECUTION SUMMARY")
    print("="*60)
    
    for description, success in results:
        status = "✅" if success else "❌"
        print(f"  {status} {description}")
    
    if all(success for _, success in results):
        print("\n🎉 All pipeline steps completed successfully!")
        return 0
    else:
        print("\n⚠️ Pipeline completed with errors")
        return 1

if __name__ == "__main__":
    sys.exit(main())