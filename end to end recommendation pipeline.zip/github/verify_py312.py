import sys
print(f"Python version: {sys.version}")

try:
    import pandas as pd
    print(f"✅ pandas {pd.__version__}")
except Exception as e:
    print(f"❌ pandas: {e}")

try:
    import numpy as np
    print(f"✅ numpy {np.__version__}")
except Exception as e:
    print(f"❌ numpy: {e}")

try:
    import sklearn
    print(f"✅ scikit-learn {sklearn.__version__}")
except Exception as e:
    print(f"❌ scikit-learn: {e}")

try:
    import scipy
    print(f"✅ scipy {scipy.__version__}")
except Exception as e:
    print(f"❌ scipy: {e}")

try:
    import matplotlib
    print(f"✅ matplotlib {matplotlib.__version__}")
except Exception as e:
    print(f"❌ matplotlib: {e}")

try:
    import seaborn as sns
    print(f"✅ seaborn {sns.__version__}")
except Exception as e:
    print(f"❌ seaborn: {e}")

print("\n🎉 Environment is ready for Python 3.12!")