"""Create submission package for assignment"""

import shutil
from pathlib import Path
import zipfile

def create_submission():
    """Package all deliverables"""
    
    # Define what to include
    deliverables = {
        '01_Problem_Formulation': [],
        '02_Data_Collection_Ingestion': ['scripts/ingest_data.py', 'logs/ingestion.log'],
        '04_Data_Profiling_Validation': ['scripts/generate_quality_report.py', 'data_quality_report.json'],
        '05_Data_Preparation': ['scripts/prepare_data.py', 'scripts/generate_plots.py', 'plots/'],
        '06_Feature_Engineering_Transformation': ['scripts/feature_engineering.py', 'outputs/'],
        '07_Feature_Store': ['feature_metadata.md'],
        '08_Data_Versioning_Lineage': [],  # Add DVC files
        '09_Model_Training_Evaluation': ['scripts/train_model.py', 'model_artifacts/', 'model_performance_report.json'],
        '10_Pipeline_Orchestration': ['run_pipeline.py']
    }
    
    # Create submission directory
    submission_dir = Path("submission")
    submission_dir.mkdir(exist_ok=True)
    
    # Copy files
    for folder, patterns in deliverables.items():
        folder_path = Path(folder)
        if folder_path.exists():
            for pattern in patterns:
                src = folder_path / pattern
                if src.exists():
                    dest = submission_dir / folder / pattern
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    if src.is_dir():
                        shutil.copytree(src, dest, dirs_exist_ok=True)
                    else:
                        shutil.copy2(src, dest)
    
    print("✅ Submission package created in 'submission' folder")
    
    # Create zip file
    zip_path = Path("RecoMart_Assignment_Submission.zip")
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for file in submission_dir.rglob("*"):
            zipf.write(file, file.relative_to(submission_dir.parent))
    
    print(f"✅ Zip file created: {zip_path}")

if __name__ == "__main__":
    create_submission()