@echo off
cd "D:\sandeep\MTech\Semester 2\DMML\Assignment\End to End Run"

echo ==================================================
echo FIX: Remove Data Files from Git, Add to DVC
echo ==================================================

echo.
echo Step 1: Remove ALL data files from Git tracking
echo (Your actual files will remain on disk)
git rm -r --cached data/
git commit -m "Remove data files from Git (switch to DVC)"

echo.
echo Step 2: Update .gitignore
echo # Data files - tracked by DVC, not Git > .gitignore
echo data/raw_storage/ >> .gitignore
echo data/raw_input/ >> .gitignore
echo data/processed/ >> .gitignore
echo data/features/ >> .gitignore
echo *.parquet >> .gitignore
echo *.csv >> .gitignore
echo *.pkl >> .gitignore
echo __pycache__/ >> .gitignore
echo recommender_env/ >> .gitignore
echo .env >> .gitignore
echo .dvc/ >> .gitignore

echo.
echo Step 3: Verify Git no longer tracks data files
git status

echo.
echo Step 4: Add data directories to DVC
dvc add data/raw_storage
dvc add data/processed
dvc add data/features

echo.
echo Step 5: Add DVC files to Git
git add data/*.dvc .gitignore
git commit -m "Add DVC-tracked data"

echo.
echo Step 6: Setup DVC remote storage
mkdir D:\dvc-storage 2>nul
dvc remote add -d local-storage D:\dvc-storage

echo.
echo ==================================================
echo COMPLETE!
echo ==================================================
echo.
echo To verify Git is NOT tracking data:
git ls-files | findstr "parquet"
echo If nothing shows, SUCCESS!
echo.
echo To verify DVC IS tracking data:
dvc status
echo.

pause