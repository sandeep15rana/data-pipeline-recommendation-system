# Data Versioning and Lineage Documentation

## DVC Setup Commands Executed

```bash
# Initialize DVC
dvc init

# Add data directories to DVC
dvc add data/raw_storage/
dvc add data/processed/
dvc add data/features/

# Set up remote storage
dvc remote add -d local-storage D:/dvc-storage
mkdir D:/dvc-storage

# Push data to remote
dvc push

```
