# Submission Checklist

## Required Files

- [ ] `01_Problem_Formulation/Problem_Formulation_Report.pdf`
- [ ] `02_Data_Collection_Ingestion/scripts/ingest_data.py`
- [ ] `02_Data_Collection_Ingestion/logs/ingestion.log`
- [ ] `04_Data_Profiling_Validation/data_quality_report.json`
- [ ] `05_Data_Preparation/plots/*.png` (4+ plots)
- [ ] `06_Feature_Engineering_Transformation/outputs/*.parquet`
- [ ] `07_Feature_Store/feature_metadata.md`
- [ ] `08_Data_Versioning_Lineage/versioning_workflow.md`
- [ ] `09_Model_Training_Evaluation/model_artifacts/*.pkl`
- [ ] `09_Model_Training_Evaluation/model_performance_report.json`
- [ ] `run_pipeline.py`
- [ ] `Final_Report.pdf`
- [ ] `Video_Walkthrough.mp4`

## Generate Final Package

```bash

# Create zip file
zip -r RecoMart_Assignment_Submission.zip \
    01_Problem_Formulation/ \
    02_Data_Collection_Ingestion/ \
    04_Data_Profiling_Validation/ \
    05_Data_Preparation/plots/ \
    06_Feature_Engineering_Transformation/outputs/ \
    07_Feature_Store/ \
    09_Model_Training_Evaluation/ \
    run_pipeline.py \
    Final_Report.pdf \
    Video_Walkthrough.mp4
```
