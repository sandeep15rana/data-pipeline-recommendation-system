#!/usr/bin/env python3
"""
Data Ingestion Script for RecoMart Pipeline
"""

import pandas as pd
import logging
import sys
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/ingestion.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def ingest_interactions():
    """Ingest interactions data"""
    
    try:
        # Find latest interactions file
        input_dir = Path("data/raw_input")
        csv_files = list(input_dir.glob("interactions_*.csv"))
        
        if not csv_files:
            logger.error("No interactions CSV files found")
            return False
        
        source_path = max(csv_files, key=lambda f: f.stat().st_mtime)
        logger.info(f"Reading data from {source_path}")
        
        df = pd.read_csv(source_path)
        logger.info(f"Read {len(df)} records")
        
        # Convert timestamp to datetime
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Add ingestion metadata
        df['ingestion_timestamp'] = datetime.now()
        
        # Create partition folders
        today = datetime.now()
        dest_path = Path("data/raw_storage/interactions") / f"year={today.year}" / f"month={today.month:02d}" / f"day={today.day:02d}"
        dest_path.mkdir(parents=True, exist_ok=True)
        
        # Save as Parquet
        output_file = dest_path / f"interactions_{today.strftime('%Y%m%d_%H%M%S')}.parquet"
        df.to_parquet(output_file, index=False)
        
        logger.info(f"✅ Successfully ingested {len(df)} records to {output_file}")
        return True
        
    except Exception as e:
        logger.error(f"Ingestion failed: {str(e)}")
        return False

def ingest_products():
    """Ingest products data"""
    
    try:
        input_dir = Path("data/raw_input")
        csv_files = list(input_dir.glob("products_*.csv"))
        
        if not csv_files:
            logger.error("No products CSV files found")
            return False
        
        source_path = max(csv_files, key=lambda f: f.stat().st_mtime)
        logger.info(f"Reading data from {source_path}")
        
        df = pd.read_csv(source_path)
        logger.info(f"Read {len(df)} products")
        
        # Add ingestion metadata
        df['ingestion_timestamp'] = datetime.now()
        
        # Create partition folders
        today = datetime.now()
        dest_path = Path("data/raw_storage/products") / f"year={today.year}" / f"month={today.month:02d}" / f"day={today.day:02d}"
        dest_path.mkdir(parents=True, exist_ok=True)
        
        # Save as Parquet
        output_file = dest_path / f"products_{today.strftime('%Y%m%d_%H%M%S')}.parquet"
        df.to_parquet(output_file, index=False)
        
        logger.info(f"✅ Successfully ingested {len(df)} products to {output_file}")
        return True
        
    except Exception as e:
        logger.error(f"Ingestion failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("🔄 Starting Data Ingestion...")
    print("=" * 50)
    
    success_int = ingest_interactions()
    success_prod = ingest_products()
    
    if success_int and success_prod:
        print("\n✅ All ingestion tasks completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Some ingestion tasks failed")
        sys.exit(1)