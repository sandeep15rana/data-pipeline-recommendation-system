# Create the entire project structure
mkdir -p DMML_Assignment
cd DMML_Assignment

# Create all assignment directories
for i in {01..10}; do
    mkdir -p ${i}_*/{scripts,notebooks,outputs,logs,plots,screenshots,sql_schema,airflow_dags,model_artifacts,mlflow_outputs}
done

# Create data directories
mkdir -p data/{raw_storage/{interactions,products,external},processed,features,model_registry}

# Create logs directory
mkdir -p logs/{airflow,mlflow,dvc}

echo "Directory structure created successfully!"