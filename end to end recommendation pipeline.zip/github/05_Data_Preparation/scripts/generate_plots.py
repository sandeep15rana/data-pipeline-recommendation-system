"""Generate EDA plots for Task 5"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("Set2")

def load_data():
    """Load cleaned data"""
    processed_dir = Path("data/processed")
    files = list(processed_dir.glob("cleaned_interactions_*.parquet"))
    
    if files:
        return pd.read_parquet(files[0])
    return None

def create_plots(interactions):
    """Create EDA visualizations"""
    
    plots_dir = Path("05_Data_Preparation/plots")
    plots_dir.mkdir(parents=True, exist_ok=True)
    
    # Plot 1: Rating Distribution
    plt.figure(figsize=(10, 6))
    interactions['rating'].hist(bins=20, edgecolor='black', alpha=0.7)
    plt.title('Distribution of User Ratings', fontsize=14)
    plt.xlabel('Rating')
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.savefig(plots_dir / 'rating_distribution.png', dpi=150)
    plt.close()
    print("✅ Saved: rating_distribution.png")
    
    # Plot 2: Interactions per User
    plt.figure(figsize=(10, 6))
    user_counts = interactions['user_id'].value_counts()
    user_counts.hist(bins=30, edgecolor='black', alpha=0.7)
    plt.title('Distribution of Interactions per User', fontsize=14)
    plt.xlabel('Number of Interactions')
    plt.ylabel('Number of Users')
    plt.tight_layout()
    plt.savefig(plots_dir / 'interactions_per_user.png', dpi=150)
    plt.close()
    print("✅ Saved: interactions_per_user.png")
    
    # Plot 3: Popular Items
    plt.figure(figsize=(12, 6))
    popular = interactions['product_id'].value_counts().head(20)
    popular.plot(kind='bar', edgecolor='black')
    plt.title('Top 20 Most Popular Products', fontsize=14)
    plt.xlabel('Product ID')
    plt.ylabel('Interaction Count')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(plots_dir / 'popular_items.png', dpi=150)
    plt.close()
    print("✅ Saved: popular_items.png")
    
    # Plot 4: Heatmap (sample for sparsity visualization)
    plt.figure(figsize=(10, 8))
    # Create a sparse matrix sample
    sample_users = interactions['user_id'].unique()[:20]
    sample_items = interactions['product_id'].unique()[:20]
    sample_data = interactions[
        (interactions['user_id'].isin(sample_users)) & 
        (interactions['product_id'].isin(sample_items))
    ]
    
    pivot = sample_data.pivot_table(
        index='user_id', 
        columns='product_id', 
        values='rating',
        fill_value=0
    )
    
    sns.heatmap(pivot, cmap='YlOrRd', cbar_kws={'label': 'Rating'})
    plt.title('User-Item Interaction Heatmap (Sample)', fontsize=14)
    plt.xlabel('Product ID')
    plt.ylabel('User ID')
    plt.tight_layout()
    plt.savefig(plots_dir / 'interaction_heatmap.png', dpi=150)
    plt.close()
    print("✅ Saved: interaction_heatmap.png")
    
    print(f"\n📊 All plots saved to: {plots_dir}")

if __name__ == "__main__":
    print("Generating EDA plots...")
    interactions = load_data()
    
    if interactions is not None:
        create_plots(interactions)
        print("\n✅ EDA visualization complete!")
    else:
        print("❌ No data found. Run pipeline first.")