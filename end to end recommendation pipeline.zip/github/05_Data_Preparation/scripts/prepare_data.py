#!/usr/bin/env python3
"""
Data Preparation and Cleaning Pipeline
"""

import pandas as pd
import numpy as np
import logging
import sys
from pathlib import Path
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_raw_data():
    """Load latest raw data from storage"""
    
    logger.info("Loading raw data...")
    
    # Load interactions
    interaction_files = list(Path("data/raw_storage/interactions").rglob("*.parquet"))
    if not interaction_files:
        logger.error("No interaction data found")
        return None, None
    
    latest_interactions = max(interaction_files, key=lambda f: f.stat().st_mtime)
    interactions = pd.read_parquet(latest_interactions)
    logger.info(f"Loaded {len(interactions)} interactions")
    
    # Load products
    product_files = list(Path("data/raw_storage/products").rglob("*.parquet"))
    if not product_files:
        logger.error("No product data found")
        return interactions, None
    
    latest_products = max(product_files, key=lambda f: f.stat().st_mtime)
    products = pd.read_parquet(latest_products)
    logger.info(f"Loaded {len(products)} products")
    
    return interactions, products

def clean_data(interactions, products):
    """Clean both datasets"""
    
    logger.info("Cleaning data...")
    
    # Clean interactions
    original_count = len(interactions)
    interactions = interactions.dropna(subset=['user_id', 'product_id'])
    interactions = interactions.drop_duplicates(subset=['user_id', 'product_id', 'timestamp'])
    
    # Fill missing ratings with median
    if interactions['rating'].isna().any():
        median_rating = interactions['rating'].median()
        interactions['rating'] = interactions['rating'].fillna(median_rating)
    
    # Remove rating outliers
    interactions = interactions[(interactions['rating'] >= 0.5) & (interactions['rating'] <= 5.0)]
    
    logger.info(f"Interactions: {original_count} -> {len(interactions)} rows")
    
    # Clean products
    if products is not None:
        products = products.dropna(subset=['product_id'])
        products = products.drop_duplicates(subset=['product_id'])
        
        if 'category' in products.columns:
            products['category'] = products['category'].fillna('Unknown')
        if 'brand' in products.columns:
            products['brand'] = products['brand'].fillna('Unknown')
        
        logger.info(f"Products: cleaned to {len(products)} rows")
    
    return interactions, products

def save_cleaned_data(interactions, products):
    """Save cleaned data"""
    
    output_dir = Path("data/processed")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    interactions_path = output_dir / f"cleaned_interactions_{timestamp}.parquet"
    interactions.to_parquet(interactions_path, index=False)
    
    if products is not None:
        products_path = output_dir / f"cleaned_products_{timestamp}.parquet"
        products.to_parquet(products_path, index=False)
        logger.info(f"✅ Saved cleaned products")
    
    logger.info(f"✅ Saved cleaned interactions to {interactions_path}")
    return interactions_path

if __name__ == "__main__":
    print("🔄 Starting Data Preparation...")
    print("=" * 50)
    
    interactions, products = load_raw_data()
    
    if interactions is None:
        logger.error("No data available")
        sys.exit(1)
    
    interactions, products = clean_data(interactions, products)
    save_cleaned_data(interactions, products)
    
    print("\n✅ Data preparation complete!")
    sys.exit(0)