"""Generate Data Quality Report for Task 4"""

import pandas as pd
import json
from pathlib import Path
from datetime import datetime

def load_data():
    """Load raw data"""
    interaction_files = list(Path("data/raw_storage/interactions").rglob("*.parquet"))
    product_files = list(Path("data/raw_storage/products").rglob("*.parquet"))
    
    interactions = pd.read_parquet(interaction_files[0]) if interaction_files else None
    products = pd.read_parquet(product_files[0]) if product_files else None
    
    return interactions, products

def generate_report(interactions, products):
    """Generate comprehensive quality report"""
    
    report = {
        'report_timestamp': datetime.now().isoformat(),
        'dataset_summary': {},
        'quality_metrics': {},
        'issues_found': []
    }
    
    if interactions is not None:
        report['dataset_summary']['interactions'] = {
            'rows': len(interactions),
            'columns': len(interactions.columns),
            'users': interactions['user_id'].nunique(),
            'products': interactions['product_id'].nunique(),
            'date_range': f"{interactions['timestamp'].min()} to {interactions['timestamp'].max()}"
        }
        
        report['quality_metrics']['interactions'] = {
            'missing_user_ids': int(interactions['user_id'].isna().sum()),
            'missing_product_ids': int(interactions['product_id'].isna().sum()),
            'missing_ratings': int(interactions['rating'].isna().sum()),
            'duplicate_rows': int(interactions.duplicated().sum()),
            'rating_range_valid': float(((interactions['rating'] >= 0.5) & (interactions['rating'] <= 5.0)).mean() * 100)
        }
        
        if interactions['rating'].isna().sum() > 0:
            report['issues_found'].append("Missing ratings found")
    
    if products is not None:
        report['dataset_summary']['products'] = {
            'rows': len(products),
            'unique_products': products['product_id'].nunique(),
            'categories': products['category'].nunique() if 'category' in products.columns else 0
        }
    
    # Save report
    output_path = Path("04_Data_Profiling_Validation/data_quality_report.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    print(f"✅ Quality report saved to {output_path}")
    return report

if __name__ == "__main__":
    print("Generating Data Quality Report...")
    interactions, products = load_data()
    report = generate_report(interactions, products)
    
    # Print summary
    print("\n" + "="*50)
    print("QUALITY REPORT SUMMARY")
    print("="*50)
    print(json.dumps(report, indent=2, default=str)[:1000])