# Feature Store Documentation - RecoMart

## Feature Registry

### User Features

| Feature Name           | Data Type | Description                        | Source               |
| ---------------------- | --------- | ---------------------------------- | -------------------- |
| user_id                | INT64     | Unique user identifier             | interactions.parquet |
| interaction_count      | INT64     | Total number of user interactions  | aggregated           |
| avg_rating             | FLOAT64   | Average rating given by user       | aggregated           |
| rating_std             | FLOAT64   | Standard deviation of user ratings | aggregated           |
| interaction_count_norm | FLOAT64   | Normalized interaction count (0-1) | transformed          |

### Item Features

| Feature Name      | Data Type | Description                 | Source           |
| ----------------- | --------- | --------------------------- | ---------------- |
| product_id        | INT64     | Unique product identifier   | products.parquet |
| interaction_count | INT64     | Total product interactions  | aggregated       |
| avg_rating        | FLOAT64   | Average rating received     | aggregated       |
| popularity_norm   | FLOAT64   | Normalized popularity score | transformed      |
| category          | STRING    | Product category            | products.parquet |
| price             | FLOAT64   | Product price               | products.parquet |

## Feature Versioning

- Current Version: v1.0
- Last Updated: [Current Date]
- Schema Version: 1

## Access Patterns

- **Batch Training**: Full feature set retrieval
- **Online Inference**: Single entity retrieval by ID

## Feature Lineage
