#!/usr/bin/env python3
"""
Generate synthetic e-commerce data for RecoMart pipeline
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from pathlib import Path

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

def generate_interactions(num_users=200, num_products=100, num_interactions=10000):
    """Generate synthetic user-product interactions"""
    
    print(f"Generating {num_interactions} interactions...")
    
    interactions = []
    start_date = datetime(2024, 1, 1)
    end_date = datetime(2024, 1, 31)
    
    for i in range(num_interactions):
        user_id = np.random.randint(1, num_users + 1)
        product_id = np.random.randint(1, num_products + 1)
        
        # Rating distribution: more 3-5 ratings than 1-2
        if np.random.random() < 0.7:
            rating = np.random.choice([3.0, 3.5, 4.0, 4.5, 5.0])
        else:
            rating = np.random.choice([0.5, 1.0, 1.5, 2.0, 2.5])
        
        # Random timestamp in January 2024
        random_days = np.random.randint(0, 31)
        random_hours = np.random.randint(0, 24)
        timestamp = start_date + timedelta(days=random_days, hours=random_hours)
        
        interactions.append({
            'user_id': user_id,
            'product_id': product_id,
            'rating': rating,
            'timestamp': timestamp
        })
    
    df = pd.DataFrame(interactions)
    
    # Add some missing values (simulate real-world data issues)
    missing_indices = np.random.choice(df.index, size=int(len(df)*0.02), replace=False)
    df.loc[missing_indices, 'rating'] = np.nan
    
    print(f"Generated {len(df)} interactions with {df['rating'].isna().sum()} missing ratings")
    return df

def generate_products(num_products=100):
    """Generate synthetic product catalog"""
    
    categories = ['Electronics', 'Clothing', 'Books', 'Home & Garden', 'Sports', 
                  'Toys', 'Beauty', 'Automotive', 'Groceries', 'Office Supplies']
    brands = ['BrandA', 'BrandB', 'BrandC', 'BrandD', 'BrandE', 'BrandF', 
              'BrandG', 'BrandH', 'BrandI', 'BrandJ']
    
    products = []
    for i in range(1, num_products + 1):
        products.append({
            'product_id': i,
            'name': f'Product_{i}',
            'category': np.random.choice(categories),
            'brand': np.random.choice(brands),
            'price': round(np.random.uniform(5, 500), 2),
            'stock_quantity': np.random.randint(0, 1000),
            'rating_average': round(np.random.uniform(2.5, 5.0), 1)
        })
    
    return pd.DataFrame(products)

def save_data(interactions_df, products_df):
    """Save data to appropriate locations"""
    
    # Create raw_input directory
    raw_input_dir = Path("data/raw_input")
    raw_input_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    interactions_path = raw_input_dir / f"interactions_{timestamp}.csv"
    products_path = raw_input_dir / f"products_{timestamp}.csv"
    
    interactions_df.to_csv(interactions_path, index=False)
    products_df.to_csv(products_path, index=False)
    
    print(f"✅ Saved interactions to: {interactions_path}")
    print(f"✅ Saved products to: {products_path}")
    
    return interactions_path, products_path

if __name__ == "__main__":
    print("=" * 50)
    print("RecoMart Data Generator")
    print("=" * 50)
    
    # Generate data
    interactions = generate_interactions(num_users=200, num_products=100, num_interactions=10000)
    products = generate_products(num_products=100)
    
    # Display stats
    print("\n📊 Data Statistics:")
    print(f"  - Users: {interactions['user_id'].nunique()}")
    print(f"  - Products: {interactions['product_id'].nunique()}")
    print(f"  - Interactions: {len(interactions)}")
    print(f"  - Rating range: {interactions['rating'].min():.1f} - {interactions['rating'].max():.1f}")
    
    # Save data
    save_data(interactions, products)
    
    print("\n✨ Data generation complete!")