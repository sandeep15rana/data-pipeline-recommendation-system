#!/usr/bin/env python3
"""
Feature Engineering for Recommendation System
"""

import pandas as pd
import numpy as np
import logging
import sys
from pathlib import Path
from datetime import datetime
from sklearn.preprocessing import MinMaxScaler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_cleaned_data():
    """Load latest cleaned data"""
    
    processed_dir = Path("data/processed")
    interaction_files = list(processed_dir.glob("cleaned_interactions_*.parquet"))
    
    if not interaction_files:
        logger.error("No cleaned data found")
        return None, None
    
    latest_interactions = max(interaction_files, key=lambda f: f.stat().st_mtime)
    interactions = pd.read_parquet(latest_interactions)
    logger.info(f"Loaded {len(interactions)} interactions")
    
    # Load products if available
    product_files = list(processed_dir.glob("cleaned_products_*.parquet"))
    products = None
    if product_files:
        latest_products = max(product_files, key=lambda f: f.stat().st_mtime)
        products = pd.read_parquet(latest_products)
        logger.info(f"Loaded {len(products)} products")
    
    return interactions, products

def create_features(interactions, products):
    """Create user and item features"""
    
    logger.info("Creating features...")
    
    # User features
    user_features = interactions.groupby('user_id').agg({
        'product_id': 'count',
        'rating': ['mean', 'std']
    }).round(4)
    user_features.columns = ['interaction_count', 'avg_rating', 'rating_std']
    user_features = user_features.reset_index()
    user_features['rating_std'] = user_features['rating_std'].fillna(0)
    
    # Normalize user interaction count
    scaler = MinMaxScaler()
    user_features['interaction_count_norm'] = scaler.fit_transform(user_features[['interaction_count']])
    
    # Item features
    item_features = interactions.groupby('product_id').agg({
        'user_id': 'count',
        'rating': ['mean', 'std']
    }).round(4)
    item_features.columns = ['interaction_count', 'avg_rating', 'rating_std']
    item_features = item_features.reset_index()
    item_features['rating_std'] = item_features['rating_std'].fillna(0)
    
    # Normalize item popularity
    item_features['popularity_norm'] = scaler.fit_transform(item_features[['interaction_count']])
    
    logger.info(f"Created features for {len(user_features)} users and {len(item_features)} items")
    
    return user_features, item_features

def save_features(user_features, item_features):
    """Save feature sets"""
    
    output_dir = Path("data/features")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    user_path = output_dir / f"user_features_{timestamp}.parquet"
    item_path = output_dir / f"item_features_{timestamp}.parquet"
    
    user_features.to_parquet(user_path, index=False)
    item_features.to_parquet(item_path, index=False)
    
    logger.info(f"✅ Saved features to {output_dir}")
    return user_path, item_path

if __name__ == "__main__":
    print("🔧 Starting Feature Engineering...")
    print("=" * 50)
    
    interactions, products = load_cleaned_data()
    
    if interactions is None:
        logger.error("No data available")
        sys.exit(1)
    
    user_features, item_features = create_features(interactions, products)
    save_features(user_features, item_features)
    
    print("\n✅ Feature engineering complete!")
    sys.exit(0)