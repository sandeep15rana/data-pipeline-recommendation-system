@echo off
echo ==================================================
echo Creating Submission Package
echo ==================================================
echo.

:: Change to project directory (Update this path!)
cd /d "D:\sandeep\MTech\Semester 2\DMML\Assignment\End to End Run"

echo Step 1: Creating missing directories...
mkdir 01_Problem_Formulation 2>nul
mkdir 07_Feature_Store 2>nul
mkdir 08_Data_Versioning_Lineage 2>nul
echo.

echo Step 2: Creating placeholder files for missing documents...
if not exist "01_Problem_Formulation\Problem_Formulation_Report.pdf" (
    echo Creating placeholder Problem Formulation...
    echo # Problem Formulation Report > 01_Problem_Formulation\Problem_Formulation_Report.pdf.tmp
    ren 01_Problem_Formulation\Problem_Formulation_Report.pdf.tmp Problem_Formulation_Report.pdf
)

if not exist "07_Feature_Store\feature_metadata.md" (
    echo Creating placeholder Feature Store documentation...
    echo # Feature Store Documentation > 07_Feature_Store\feature_metadata.md
    echo. >> 07_Feature_Store\feature_metadata.md
    echo ## Features >> 07_Feature_Store\feature_metadata.md
)

if not exist "08_Data_Versioning_Lineage\versioning_workflow.md" (
    echo Creating placeholder Versioning documentation...
    echo # Data Versioning Workflow > 08_Data_Versioning_Lineage\versioning_workflow.md
)

if not exist "Final_Report.pdf" (
    echo Creating placeholder Final Report...
    echo Placeholder > Final_Report.pdf
)

if not exist "Video_Walkthrough.mp4" (
    echo Creating placeholder Video...
    echo Placeholder > Video_Walkthrough.mp4
)
echo.

echo Step 3: Creating zip file using PowerShell...
powershell -Command "Compress-Archive -Path '01_Problem_Formulation','02_Data_Collection_Ingestion','04_Data_Profiling_Validation','05_Data_Preparation/plots','06_Feature_Engineering_Transformation/outputs','07_Feature_Store','08_Data_Versioning_Lineage','09_Model_Training_Evaluation','run_pipeline.py','Final_Report.pdf','Video_Walkthrough.mp4' -DestinationPath 'RecoMart_Assignment_Submission.zip' -Force"

echo.
if exist "RecoMart_Assignment_Submission.zip" (
    echo ==================================================
    echo SUCCESS! Zip file created!
    echo ==================================================
    echo.
    echo File: RecoMart_Assignment_Submission.zip
    dir RecoMart_Assignment_Submission.zip
) else (
    echo ==================================================
    echo ERROR: Zip file was not created
    echo ==================================================
)

echo.
pause